from .inventario import Inventario
from .Items import arma, consumivel
from .Comparators import comparador_peso, comparador_valor