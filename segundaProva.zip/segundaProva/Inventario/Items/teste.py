def teste():
  print("teste")